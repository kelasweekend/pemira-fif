<?php $__env->startSection('title'); ?>
    Calon dan Wakil Calon
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- breadcumb -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 float-right">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="#">Admin</a></li>
                            <li class="breadcrumb-item active"><?php echo $__env->yieldContent('title'); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <?php if($message = Session::get('success')): ?>
                                <div class="alert alert-success alert-block">
                                    <button type="button" class="close" data-dismiss="alert">×</button>
                                    <strong><?php echo e($message); ?></strong>
                                </div>
                            <?php endif; ?>
                            <div class="card">
                                <div class="card-header">
                                    <h2 class="card-title"><?php echo $__env->yieldContent('title'); ?></h2>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('calon-create')): ?>
                                        <a href="<?php echo e(route('pemira.create')); ?>"
                                            class="btn btn-outline-primary btn-sm waves-effect waves-light float-right">Create
                                            Paslon</a>
                                    <?php endif; ?>
                                </div>
                                <!-- /.card-header -->
                                <div class="card-body">
                                    <table id="example2" class="table table-bordered table-hover data-table">
                                        <thead>
                                            <tr>
                                                <th>Nomor Urut</th>
                                                <th>Ketua</th>
                                                <th>Wakil</th>
                                                <th>Jurusan</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $calon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <th><?php echo e($item->nomor_urut); ?></th>
                                                    <th><?php echo e($item->nama_ketua); ?></th>
                                                    <th><?php echo e($item->nama_wakil); ?></th>
                                                    <th><?php echo e($item->jurusan); ?></th>
                                                    <th>
                                                        <div class="d-flex">
                                                            <a href="<?php echo e(route('pemira.edit', $item->id)); ?>"
                                                                class="btn btn-warning btn-sm mr-2"><i
                                                                    class="fas fa-edit"></i></a>
                                                            <form action="<?php echo e(route('pemira.destroy', $item->id)); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                                <button class="btn btn-danger btn-sm" type="submit"><i
                                                                        class="fas fa-trash"></i></button>
                                                            </form>
                                                        </div>
                                                    </th>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>Nomor Urut</th>
                                                <th>Ketua</th>
                                                <th>Wakil</th>
                                                <th>Jurusan</th>
                                                <th>Action</th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                                <!-- /.card-body -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- /.content-header -->
    </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-store')): ?>
        <div class="modal fade" id="ajaxModel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modelHeading"></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="ItemForm" name="ItemForm" class="form-horizontal">
                            <input type="hidden" name="Item_id" id="Item_id">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Nama Permissions</label>
                                            <?php echo Form::text('name', null, ['placeholder' => 'Nama Permission', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-12">
                                        <div class="form-group">
                                            <label>Guard Name</label>
                                            <?php echo Form::text('guard_name', null, ['placeholder' => 'Guard Name', 'class' => 'form-control']); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-offset-2 col-sm-10">
                                <button class="btn btn-primary tombol" id="saveBtn" value="create"></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css-tambahan'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('cdn/datatables/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cdn/datatables/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('cdn/datatables/datatables-buttons/css/buttons.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-tambahan'); ?>
    <!-- DataTables  & Plugins -->
    <script src="<?php echo e(asset('cdn/datatables/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('cdn/datatables/datatables-buttons/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    
    <script>
        $(function() {
            $("#example2").DataTable({
                "responsive": true,
                "lengthChange": true,
                pageLength: 5,
                lengthMenu: [5, 10, 20, 50, 100, 200, 500],
                "autoWidth": false,
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ojan\pemira-fif\resources\views/pemira/calon.blade.php ENDPATH**/ ?>