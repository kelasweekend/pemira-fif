<?php $__env->startSection('title'); ?>
    QuickCount Pemira 2021
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- section one -->
    <section class="one">
        <h4 class="text-center judul">QuickCount</h4>
        <h5 class="text-center text-muted mt-4">Pantauan Hasil Suara Pemira</h5>
        <div class="container">
            <div class="row justify-content-center mt-5">
                <div class="col-md-6 col-12">
                    <canvas id="myChart" width="100px"></canvas>
                </div>
                <div class="col-md-6 col-12">
                    

                    <?php $__currentLoopData = $paslon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card p-3 bayangan_2 vote_hasil">
                            <div class="d-flex mb-2">
                                <h5 class="font-weight-bold">Paslon #<?php echo e($calon->nomor_urut); ?></h5>
                                <button type="button" id="hasil-<?php echo e($calon->id); ?>" data-paslon="<?php echo e($calon->id); ?>"
                                    class="btn btn-secondary btn-sm ml-auto"
                                    data-url="<?php echo e(route('hasil_vote', $calon->id)); ?>"><i class="fas fa-sync"></i>
                                    Refresh</button>
                            </div>
                            <div class="progress mt-1">
                                <div class="progress-bar paslon-<?php echo e($calon->id); ?>" role="progressbar" style="width: 0%;"
                                    aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js-tambahan'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script type="text/javascript">
        let pemilih = <?php echo e($total_pemilih); ?>

        let suara = <?php echo e($suara_masuk); ?>

        let golput = <?php echo e($golput); ?>

        const datasheet = {
            labels: [
                'Total Suara',
                'Suara Masuk',
                'Golput'
            ],
            datasets: [{
                label: 'Realtime Quick Count',
                data: [pemilih, suara, golput],
                backgroundColor: [
                    'rgb(255, 99, 132)',
                    'rgb(75, 192, 192)',
                    'rgb(201, 203, 207)',
                ]
            }]
        };
        const configurasi = {
            type: 'polarArea',
            data: datasheet,
            options: {}
        };
        var myChart = new Chart(
            document.getElementById('myChart'),
            configurasi
        );

    </script>
    <?php $__currentLoopData = $paslon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script type="text/javascript">
            $(document).ready(function() {
                $("#hasil-<?php echo e($item->id); ?>").click(function() {
                    var paslon = $(this).data('paslon');
                    let url = $(this).data('url');
                    $.get(url, function(data) {
                        console.log(data + "%")
                        console.log("paslon ke " + paslon)
                        $(".paslon-" + paslon).css("width", data + "%");
                        $(".paslon-" + paslon).text(data + "%");
                    })
                });
            });

        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ojan\pemira-fif\resources\views/frontend/quickcount.blade.php ENDPATH**/ ?>